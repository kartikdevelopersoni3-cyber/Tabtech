@rem Gradle startup script for Windows
@rem
@if "%DEBUG%" == "" @echo off
@setlocal
@rem Set local scope for the variables with windows NT shell
set APP_HOME=%~dp0
set APP_NAME=Gradle
set APP_BASE_NAME=%~n0
set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"
java %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%APP_BASE_NAME%" -classpath "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
