package com.roohi.app.reasoning.domain.models
data class ReasoningContext(val userInput: String, val intent: String, val memories: List<String> = emptyList(), val preferences: Map<String, String> = emptyMap(), val timestamp: Long = System.currentTimeMillis())
