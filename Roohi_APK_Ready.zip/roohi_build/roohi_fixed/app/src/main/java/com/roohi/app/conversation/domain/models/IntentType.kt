package com.roohi.app.conversation.domain.models
enum class IntentType { QUESTION, COMMAND, CASUAL, EMOTIONAL_SUPPORT, REMINDER, UNKNOWN }
