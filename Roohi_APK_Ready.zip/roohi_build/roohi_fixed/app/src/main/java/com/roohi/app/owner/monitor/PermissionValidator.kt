package com.roohi.app.owner.monitor
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class PermissionValidator @Inject constructor(private val logger: Logger) {
    fun validate(): Boolean = true
}
