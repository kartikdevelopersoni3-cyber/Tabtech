package com.roohi.app.identity.domain.models
import com.roohi.app.identity.domain.models.PermissionHealth
import com.roohi.app.identity.domain.models.SetupState
data class SystemIdentityDiagnostics(
    val isOwnerRegistered: Boolean,
    val voiceProfileStatus: String,
    val setupState: SetupState,
    val emergencyContactCount: Int,
    val apiConfigured: Boolean,
    val deviceRegistered: Boolean,
    val permissionHealth: PermissionHealth,
    val securityStatus: String,
    val systemReadiness: Boolean
)
