package com.roohi.app.command.domain.models
import com.roohi.app.command.domain.models.CommandType
data class ParsedCommand(val type: CommandType, val parameter: String, val rawText: String)
