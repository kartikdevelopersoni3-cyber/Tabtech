package com.roohi.app.knowledge.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [KnowledgeEntity::class, RelationshipEntity::class], version = 1, exportSchema = false)
abstract class KnowledgeDatabase : RoomDatabase() {
    abstract fun knowledgeDao(): KnowledgeDao
}
