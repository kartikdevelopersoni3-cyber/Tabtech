package com.roohi.app.owner.domain
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class PermissionSetupManager @Inject constructor(private val logger: Logger) {
    fun isSetupComplete(): Boolean = false
}
