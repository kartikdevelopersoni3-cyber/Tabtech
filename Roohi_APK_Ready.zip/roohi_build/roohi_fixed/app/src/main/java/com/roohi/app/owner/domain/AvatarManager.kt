package com.roohi.app.owner.domain
import com.roohi.app.owner.data.AvatarStorageLayer
import com.roohi.app.owner.data.ThemeRepository
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class AvatarManager @Inject constructor(
    private val storage: AvatarStorageLayer,
    private val themeRepo: ThemeRepository,
    private val logger: Logger
) {
    fun getCurrentAvatarPath(): String? = storage.getAvatarPath()
}
