package com.roohi.app.owner.data
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class OwnerSettingsRepository @Inject constructor(private val logger: Logger) {
    fun getSetting(key: String): String? = null
    fun saveSetting(key: String, value: String) { logger.d("OwnerSettings", "Saved $key") }
}
