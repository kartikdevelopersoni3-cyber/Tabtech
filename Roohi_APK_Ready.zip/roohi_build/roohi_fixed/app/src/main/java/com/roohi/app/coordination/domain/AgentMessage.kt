package com.roohi.app.coordination.domain
data class AgentMessage(val fromAgent: String, val toAgent: String, val type: String, val payload: String, val timestamp: Long = System.currentTimeMillis())
