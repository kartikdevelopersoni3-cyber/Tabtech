package com.roohi.app.execution.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface TaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTask(task: TaskEntity)
    @Query("SELECT * FROM tasks WHERE status = 'ACTIVE'") suspend fun getActiveTasks(): List<TaskEntity>
    @Query("SELECT * FROM tasks") fun observeAllTasks(): Flow<List<TaskEntity>>
    @Query("UPDATE tasks SET status = :status WHERE id = :id") suspend fun updateStatus(id: String, status: String)
    @Delete suspend fun deleteTask(task: TaskEntity)
}
