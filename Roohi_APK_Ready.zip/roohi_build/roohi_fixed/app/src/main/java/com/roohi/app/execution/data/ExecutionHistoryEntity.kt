package com.roohi.app.execution.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "execution_history")
data class ExecutionHistoryEntity(@PrimaryKey val id: String, val taskId: String, val result: String, val durationMs: Long, val executedAt: Long = System.currentTimeMillis())
