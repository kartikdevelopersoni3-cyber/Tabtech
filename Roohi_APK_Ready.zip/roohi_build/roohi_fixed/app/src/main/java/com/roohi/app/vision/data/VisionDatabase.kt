package com.roohi.app.vision.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [VisualMemoryEntity::class], version = 1, exportSchema = false)
abstract class VisionDatabase : RoomDatabase() {
    abstract fun visionDao(): VisionDao
}
