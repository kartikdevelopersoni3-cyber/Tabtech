package com.roohi.app.proactive.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [RecommendationEntity::class], version = 1, exportSchema = false)
abstract class ProactiveDatabase : RoomDatabase() {
    abstract fun proactiveDao(): ProactiveDao
}
