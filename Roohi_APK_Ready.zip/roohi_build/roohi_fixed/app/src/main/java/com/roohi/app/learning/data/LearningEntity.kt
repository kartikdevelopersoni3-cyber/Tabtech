package com.roohi.app.learning.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "learning_records")
data class LearningEntity(@PrimaryKey val id: String, val category: String, val insight: String, val confidence: Float = 0.5f, val learnedAt: Long = System.currentTimeMillis())
