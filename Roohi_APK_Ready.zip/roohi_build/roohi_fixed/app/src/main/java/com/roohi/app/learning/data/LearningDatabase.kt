package com.roohi.app.learning.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [LearningEntity::class], version = 1, exportSchema = false)
abstract class LearningDatabase : RoomDatabase() {
    abstract fun learningDao(): LearningDao
}
