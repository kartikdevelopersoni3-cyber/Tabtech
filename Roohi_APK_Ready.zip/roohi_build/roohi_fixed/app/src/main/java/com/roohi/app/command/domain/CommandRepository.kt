package com.roohi.app.command.domain
import com.roohi.app.command.domain.models.ExecutionResult
interface CommandRepository {
    suspend fun saveExecutionResult(result: ExecutionResult)
    suspend fun getRecentResults(limit: Int): List<ExecutionResult>
}
