package com.roohi.app.vision.domain
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class VisionManager @Inject constructor(private val logger: Logger) {
    fun isAvailable(): Boolean = false
    fun captureAndDescribe(): String = "Vision unavailable"
}
