package com.roohi.app.reasoning.domain.models
data class Goal(val id: String, val description: String, val status: GoalStatus = GoalStatus.PENDING, val priority: Int = 0, val createdAt: Long = System.currentTimeMillis())
