package com.roohi.app.vision.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "visual_memories")
data class VisualMemoryEntity(@PrimaryKey val id: String, val description: String, val imagePath: String? = null, val capturedAt: Long = System.currentTimeMillis(), val tags: String = "")
