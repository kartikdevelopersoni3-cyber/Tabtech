package com.roohi.app.identity.domain.models
data class OwnerProfile(val id: String, val name: String, val createdAt: Long, val voiceEnrolled: Boolean = false)
