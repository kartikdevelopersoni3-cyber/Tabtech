package com.roohi.app.device.domain
import android.content.Context
import com.roohi.app.core.logging.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class AutomationManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val logger: Logger
) {
    fun isActive(): Boolean = false
}
