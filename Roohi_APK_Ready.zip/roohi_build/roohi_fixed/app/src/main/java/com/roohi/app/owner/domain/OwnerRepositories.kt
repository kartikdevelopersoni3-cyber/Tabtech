package com.roohi.app.owner.domain
import com.roohi.app.owner.domain.models.CharacterProfile
import com.roohi.app.owner.domain.models.OwnerProfile
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class OwnerProfileRepository @Inject constructor(private val logger: Logger) {
    private var profile: OwnerProfile? = null
    fun getProfile(): OwnerProfile? = profile
    fun saveProfile(p: OwnerProfile) { profile = p }
}
