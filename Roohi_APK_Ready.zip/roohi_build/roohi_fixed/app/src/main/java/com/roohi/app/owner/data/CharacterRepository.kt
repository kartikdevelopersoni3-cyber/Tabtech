package com.roohi.app.owner.data
import com.roohi.app.core.logging.Logger
import com.roohi.app.owner.domain.models.CharacterProfile
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class CharacterRepository @Inject constructor(private val logger: Logger) {
    fun getCharacter(): CharacterProfile? = null
    fun saveCharacter(profile: CharacterProfile) { logger.d("CharacterRepo", "Saved ${profile.characterName}") }
}
