package com.roohi.app.identity.domain.models
data class EmergencyContact(val id: String, val name: String, val phone: String, val relationship: String)
