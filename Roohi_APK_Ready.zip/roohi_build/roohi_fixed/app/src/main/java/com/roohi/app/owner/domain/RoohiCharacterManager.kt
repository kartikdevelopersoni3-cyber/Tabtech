package com.roohi.app.owner.domain
import com.roohi.app.owner.data.CharacterRepository
import com.roohi.app.core.logging.Logger
import com.roohi.app.owner.domain.models.CharacterProfile
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class RoohiCharacterManager @Inject constructor(
    private val repo: CharacterRepository,
    private val logger: Logger
) {
    fun getCharacter(): CharacterProfile? = repo.getCharacter()
}
