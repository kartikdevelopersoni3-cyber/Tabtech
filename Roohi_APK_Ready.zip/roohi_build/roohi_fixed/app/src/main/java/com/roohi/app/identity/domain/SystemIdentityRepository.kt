package com.roohi.app.identity.domain
import com.roohi.app.identity.domain.models.*
import kotlinx.coroutines.flow.Flow
interface SystemIdentityRepository {
    suspend fun getOwnerProfile(): OwnerProfile?
    suspend fun saveOwnerProfile(profile: OwnerProfile)
    suspend fun getSetupState(): SetupState
    suspend fun saveSetupState(state: SetupState)
    suspend fun getAllEmergencyContacts(): List<EmergencyContact>
    suspend fun saveEmergencyContact(contact: EmergencyContact)
    suspend fun getDeviceMetadata(): DeviceMetadata?
    suspend fun saveDeviceMetadata(metadata: DeviceMetadata)
    fun observeSetupState(): Flow<SetupState>
}
