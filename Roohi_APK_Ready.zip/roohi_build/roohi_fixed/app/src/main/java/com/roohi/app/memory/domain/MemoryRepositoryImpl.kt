package com.roohi.app.memory.domain
import com.roohi.app.memory.domain.models.*
import com.roohi.app.memory.data.MemoryDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class MemoryRepositoryImpl @Inject constructor(private val dao: MemoryDao) : MemoryRepository {
    override suspend fun saveMemory(record: MemoryRecord) {}
    override suspend fun getAllActiveMemories(): List<MemoryRecord> = emptyList()
    override suspend fun searchMemories(query: String): List<MemoryRecord> = emptyList()
    override suspend fun getMemoriesByType(type: MemoryType): List<MemoryRecord> = emptyList()
    override fun observeActiveMemoryCount(): Flow<Int> = flowOf(0)
    override suspend fun deleteMemory(id: String) {}
    override suspend fun updateLastAccessed(id: String, timestamp: Long) {}
}
