package com.roohi.app.personality.domain.models
data class PersonalityProfile(val name: String, val traits: Map<String, Float> = emptyMap(), val voiceStyle: String = "neutral")
