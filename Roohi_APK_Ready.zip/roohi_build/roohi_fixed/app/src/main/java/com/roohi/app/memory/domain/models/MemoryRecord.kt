package com.roohi.app.memory.domain.models
data class MemoryRecord(val id: String, val memoryType: MemoryType, val content: String, val importanceScore: Float, val sourceModule: String, val sessionId: String, val createdAt: Long, val lastAccessedAt: Long, val isActive: Boolean = true)
