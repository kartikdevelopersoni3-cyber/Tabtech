package com.roohi.app.memory.domain.models
enum class MemoryType { SHORT_TERM, LONG_TERM, EPISODIC, SEMANTIC, PREFERENCE }
