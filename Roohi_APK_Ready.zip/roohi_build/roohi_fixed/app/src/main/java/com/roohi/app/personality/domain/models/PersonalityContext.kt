package com.roohi.app.personality.domain.models
import com.roohi.app.personality.domain.models.SimulatedEmotion
data class PersonalityContext(val currentEmotion: SimulatedEmotion, val energyLevel: Float = 0.5f, val engagementLevel: Float = 0.5f)
