package com.roohi.app.reasoning.domain.models
enum class StepStatus { PENDING, IN_PROGRESS, DONE, FAILED }
