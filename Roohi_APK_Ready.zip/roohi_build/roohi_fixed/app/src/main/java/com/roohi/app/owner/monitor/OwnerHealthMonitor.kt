package com.roohi.app.owner.monitor
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class OwnerHealthMonitor @Inject constructor(
    private val apiValidator: APIValidator,
    private val avatarValidator: AvatarValidator,
    private val characterValidator: CharacterValidator,
    private val permissionValidator: PermissionValidator,
    private val logger: Logger
) {
    fun isHealthy(): Boolean = apiValidator.validate() && avatarValidator.validate() && characterValidator.validate() && permissionValidator.validate()
}
