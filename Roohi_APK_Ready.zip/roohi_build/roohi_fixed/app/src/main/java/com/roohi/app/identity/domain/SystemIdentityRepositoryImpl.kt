package com.roohi.app.identity.domain
import com.roohi.app.identity.domain.models.*
import com.roohi.app.identity.data.local.dao.IdentityDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class SystemIdentityRepositoryImpl @Inject constructor(
    private val dao: IdentityDao
) : SystemIdentityRepository {
    override suspend fun getOwnerProfile(): OwnerProfile? = null
    override suspend fun saveOwnerProfile(profile: OwnerProfile) {}
    override suspend fun getSetupState(): SetupState = SetupState.NOT_STARTED
    override suspend fun saveSetupState(state: SetupState) {}
    override suspend fun getAllEmergencyContacts(): List<EmergencyContact> = emptyList()
    override suspend fun saveEmergencyContact(contact: EmergencyContact) {}
    override suspend fun getDeviceMetadata(): DeviceMetadata? = null
    override suspend fun saveDeviceMetadata(metadata: DeviceMetadata) {}
    override fun observeSetupState(): Flow<SetupState> = flowOf(SetupState.NOT_STARTED)
}
