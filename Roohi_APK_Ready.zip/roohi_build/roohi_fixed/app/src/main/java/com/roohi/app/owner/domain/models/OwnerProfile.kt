package com.roohi.app.owner.domain.models
data class OwnerProfile(val id: String, val displayName: String, val avatarPath: String? = null, val preferredLanguage: String = "en")
