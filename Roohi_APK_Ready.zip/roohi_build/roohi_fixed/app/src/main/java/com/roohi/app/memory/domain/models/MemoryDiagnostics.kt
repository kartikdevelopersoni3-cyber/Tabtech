package com.roohi.app.memory.domain.models
data class MemoryDiagnostics(val totalActive: Int, val shortTermCount: Int, val longTermCount: Int)
