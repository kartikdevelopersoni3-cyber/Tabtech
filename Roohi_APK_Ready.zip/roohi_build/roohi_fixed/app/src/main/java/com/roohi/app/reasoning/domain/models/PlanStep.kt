package com.roohi.app.reasoning.domain.models
data class PlanStep(val id: String, val description: String, val status: StepStatus = StepStatus.PENDING, val order: Int = 0)
