package com.roohi.app.device.monitor
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class PermissionRecoveryManager @Inject constructor(private val logger: Logger) {
    fun validate(): Boolean = true
}
