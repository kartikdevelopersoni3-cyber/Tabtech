package com.roohi.app.identity.domain.models
enum class SetupState { NOT_STARTED, IN_PROGRESS, VOICE_ENROLLED, COMPLETED }
