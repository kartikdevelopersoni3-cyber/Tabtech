package com.roohi.app.device.monitor
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class DeviceHealthMonitor @Inject constructor(
    private val accessibilityValidator: AccessibilityValidator,
    private val overlayValidator: OverlayValidator,
    private val permissionWatchdog: PermissionWatchdog,
    private val diagnosticsManager: DeviceDiagnosticsManager,
    private val logger: Logger
) {
    fun isHealthy(): Boolean = accessibilityValidator.validate() && overlayValidator.validate() && permissionWatchdog.validate()
}
