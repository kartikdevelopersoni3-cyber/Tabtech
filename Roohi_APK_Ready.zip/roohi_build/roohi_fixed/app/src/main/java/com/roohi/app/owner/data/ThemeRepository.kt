package com.roohi.app.owner.data
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class ThemeRepository @Inject constructor(private val logger: Logger) {
    fun getCurrentTheme(): String = "dark"
    fun saveTheme(theme: String) { logger.d("ThemeRepo", "Theme set: $theme") }
}
