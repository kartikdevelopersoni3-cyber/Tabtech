package com.roohi.app.learning.domain
import com.roohi.app.core.logging.Logger
import com.roohi.app.learning.data.LearningDao
import com.roohi.app.learning.data.LearningEntity
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class LearningManager @Inject constructor(
    private val dao: LearningDao,
    private val logger: Logger
) {
    suspend fun learn(category: String, insight: String, confidence: Float = 0.5f) {
        try {
            dao.insertLearning(LearningEntity(UUID.randomUUID().toString(), category, insight, confidence))
            logger.d("LearningManager", "Learned: $category -> $insight")
        } catch (e: Exception) {
            logger.e("LearningManager", "Failed to persist learning", e)
        }
    }
    suspend fun getInsights(category: String): List<String> {
        return try { dao.getByCategory(category).map { it.insight } } catch (e: Exception) { emptyList() }
    }
}
