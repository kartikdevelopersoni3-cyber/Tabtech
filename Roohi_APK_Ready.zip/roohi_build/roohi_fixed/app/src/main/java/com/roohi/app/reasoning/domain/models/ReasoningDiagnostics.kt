package com.roohi.app.reasoning.domain.models
data class ReasoningDiagnostics(val activeGoals: Int, val pendingPlans: Int, val lastReasoningLatencyMs: Long, val currentSessionStatus: String, val contextConfidence: Float, val planSuccessRate: Float)
