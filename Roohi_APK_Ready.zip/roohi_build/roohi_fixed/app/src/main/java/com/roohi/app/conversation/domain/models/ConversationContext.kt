package com.roohi.app.conversation.domain.models
data class ConversationContext(val sessionId: String, val recentMessages: List<ConversationMessage> = emptyList(), val activeIntent: IntentType = IntentType.UNKNOWN, val topicStack: List<String> = emptyList())
