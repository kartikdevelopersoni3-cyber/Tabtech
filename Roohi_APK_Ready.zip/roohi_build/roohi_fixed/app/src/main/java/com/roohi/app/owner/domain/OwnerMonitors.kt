package com.roohi.app.owner.domain
import com.roohi.app.core.logging.Logger
import com.roohi.app.owner.domain.ApiConfigurationManager
import com.roohi.app.owner.domain.AvatarManager
import com.roohi.app.owner.domain.PermissionSetupManager
import com.roohi.app.owner.domain.RoohiCharacterManager
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class OwnerStatusMonitor @Inject constructor(
    private val apiConfigManager: ApiConfigurationManager,
    private val avatarManager: AvatarManager,
    private val permissionSetupManager: PermissionSetupManager,
    private val characterManager: RoohiCharacterManager,
    private val logger: Logger
) {
    fun isReady(): Boolean = true
}
