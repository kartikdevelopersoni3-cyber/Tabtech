package com.roohi.app.reasoning.domain.models
enum class GoalStatus { PENDING, ACTIVE, COMPLETED, FAILED, CANCELLED }
