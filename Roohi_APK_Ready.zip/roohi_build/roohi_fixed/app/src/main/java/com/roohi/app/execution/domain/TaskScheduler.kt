package com.roohi.app.execution.domain
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class TaskScheduler @Inject constructor(private val logger: Logger) {
    suspend fun schedule(taskId: String, delayMs: Long) {}
}
