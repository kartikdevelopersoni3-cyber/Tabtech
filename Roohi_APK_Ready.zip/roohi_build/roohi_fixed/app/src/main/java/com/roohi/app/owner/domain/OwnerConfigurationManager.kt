package com.roohi.app.owner.domain
import com.roohi.app.owner.data.OwnerSettingsRepository
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class OwnerConfigurationManager @Inject constructor(
    private val repo: OwnerSettingsRepository,
    private val logger: Logger
) {
    fun getApiKey(): String? = repo.getSetting("gemini_api_key")
    fun getOwnerName(): String = repo.getSetting("owner_name") ?: "Owner"
}
