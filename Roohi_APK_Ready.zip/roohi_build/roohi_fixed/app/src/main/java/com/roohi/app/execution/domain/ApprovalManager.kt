package com.roohi.app.execution.domain
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class ApprovalManager @Inject constructor(private val logger: Logger) {
    fun requiresApproval(action: String): Boolean = false
fun approve(actionId: String) {}
}
