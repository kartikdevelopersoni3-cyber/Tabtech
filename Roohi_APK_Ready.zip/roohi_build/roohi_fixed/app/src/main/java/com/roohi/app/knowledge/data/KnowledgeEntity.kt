package com.roohi.app.knowledge.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "knowledge_entries")
data class KnowledgeEntity(@PrimaryKey val id: String, val topic: String, val content: String, val confidence: Float = 1.0f, val createdAt: Long = System.currentTimeMillis())
