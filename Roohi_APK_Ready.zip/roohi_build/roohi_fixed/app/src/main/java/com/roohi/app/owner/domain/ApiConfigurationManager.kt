package com.roohi.app.owner.domain
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class ApiConfigurationManager @Inject constructor(private val logger: Logger) {
    fun isConfigured(): Boolean = false
    fun configure(apiKey: String) { logger.i("ApiConfig", "API key configured") }
}
