package com.roohi.app.execution.data
import androidx.room.*
@Dao
interface ExecutionHistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertHistory(history: ExecutionHistoryEntity)
    @Query("SELECT * FROM execution_history ORDER BY executedAt DESC LIMIT :limit") suspend fun getRecent(limit: Int): List<ExecutionHistoryEntity>
    @Query("DELETE FROM execution_history WHERE executedAt < :before") suspend fun deleteOlderThan(before: Long)
}
