package com.roohi.app.knowledge.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface KnowledgeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertKnowledge(entity: KnowledgeEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertRelationship(rel: RelationshipEntity)
    @Query("SELECT * FROM knowledge_entries WHERE topic LIKE '%' || :query || '%'") suspend fun searchByTopic(query: String): List<KnowledgeEntity>
    @Query("SELECT * FROM knowledge_entries") fun observeAll(): Flow<List<KnowledgeEntity>>
}
