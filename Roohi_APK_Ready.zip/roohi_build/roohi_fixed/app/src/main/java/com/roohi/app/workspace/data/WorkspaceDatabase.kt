package com.roohi.app.workspace.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [WorkspaceEntity::class], version = 1, exportSchema = false)
abstract class WorkspaceDatabase : RoomDatabase() {
    abstract fun workspaceDao(): WorkspaceDao
}
