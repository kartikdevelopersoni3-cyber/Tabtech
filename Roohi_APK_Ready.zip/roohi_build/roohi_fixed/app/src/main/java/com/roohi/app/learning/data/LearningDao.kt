package com.roohi.app.learning.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface LearningDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLearning(entity: LearningEntity)
    @Query("SELECT * FROM learning_records WHERE category = :category") suspend fun getByCategory(category: String): List<LearningEntity>
    @Query("SELECT * FROM learning_records ORDER BY learnedAt DESC") fun observeAll(): Flow<List<LearningEntity>>
}
