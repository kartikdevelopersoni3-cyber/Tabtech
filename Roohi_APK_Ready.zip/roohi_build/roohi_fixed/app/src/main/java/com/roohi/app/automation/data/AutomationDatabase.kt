package com.roohi.app.automation.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [WorkflowEntity::class, ExecutionHistoryEntity::class], version = 1, exportSchema = false)
abstract class AutomationDatabase : RoomDatabase() {
    abstract fun automationDao(): AutomationDao
}
