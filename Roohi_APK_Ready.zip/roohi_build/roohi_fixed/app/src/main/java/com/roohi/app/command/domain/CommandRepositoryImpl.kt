package com.roohi.app.command.domain
import com.roohi.app.command.domain.models.ExecutionResult
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class CommandRepositoryImpl @Inject constructor() : CommandRepository {
    override suspend fun saveExecutionResult(result: ExecutionResult) {}
    override suspend fun getRecentResults(limit: Int): List<ExecutionResult> = emptyList()
}
