package com.roohi.app.reasoning.domain
import com.roohi.app.reasoning.domain.models.*
import com.roohi.app.reasoning.data.local.dao.ReasoningDao
import com.roohi.app.reasoning.data.local.entity.GoalEntity
import com.roohi.app.reasoning.data.local.entity.PlanEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class ReasoningRepositoryImpl @Inject constructor(private val dao: ReasoningDao) : ReasoningRepository {
    override suspend fun saveGoal(goal: Goal) {}
    override suspend fun getGoalById(id: String): Goal? = null
    override suspend fun getAllActiveGoals(): List<Goal> = emptyList()
    override suspend fun updateGoalStatus(id: String, status: GoalStatus) {}
    override suspend fun savePlan(plan: Plan) {}
    override suspend fun getPlanByGoalId(goalId: String): Plan? = null
    override fun observeActiveGoals(): Flow<List<Goal>> = flowOf(emptyList())
}
