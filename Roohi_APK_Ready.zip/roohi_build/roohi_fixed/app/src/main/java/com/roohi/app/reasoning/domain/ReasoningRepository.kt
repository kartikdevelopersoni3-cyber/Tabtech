package com.roohi.app.reasoning.domain
import com.roohi.app.reasoning.domain.models.*
import kotlinx.coroutines.flow.Flow
interface ReasoningRepository {
    suspend fun saveGoal(goal: Goal)
    suspend fun getGoalById(id: String): Goal?
    suspend fun getAllActiveGoals(): List<Goal>
    suspend fun updateGoalStatus(id: String, status: GoalStatus)
    suspend fun savePlan(plan: Plan)
    suspend fun getPlanByGoalId(goalId: String): Plan?
    fun observeActiveGoals(): Flow<List<Goal>>
}
