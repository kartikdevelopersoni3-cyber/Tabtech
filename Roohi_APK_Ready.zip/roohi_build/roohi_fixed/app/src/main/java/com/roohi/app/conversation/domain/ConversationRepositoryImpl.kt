package com.roohi.app.conversation.domain
import com.roohi.app.conversation.domain.models.ConversationMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class ConversationRepositoryImpl @Inject constructor() : ConversationRepository {
    override suspend fun saveMessage(message: ConversationMessage) {}
    override suspend fun getSessionMessages(sessionId: String): List<ConversationMessage> = emptyList()
    override fun observeMessages(sessionId: String): Flow<List<ConversationMessage>> = flowOf(emptyList())
    override suspend fun deleteSession(sessionId: String) {}
}
