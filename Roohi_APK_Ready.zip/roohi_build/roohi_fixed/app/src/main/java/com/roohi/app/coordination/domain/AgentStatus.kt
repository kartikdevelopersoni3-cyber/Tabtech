package com.roohi.app.coordination.domain
enum class AgentStatus { IDLE, PROCESSING, WAITING, ERROR, OFFLINE }
