package com.roohi.app.reasoning.domain.models
enum class PlanStatus { DRAFT, ACTIVE, COMPLETED, ABANDONED }
