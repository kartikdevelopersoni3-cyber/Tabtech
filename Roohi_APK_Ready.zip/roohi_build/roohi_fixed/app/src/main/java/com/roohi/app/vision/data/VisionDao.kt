package com.roohi.app.vision.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface VisionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertVisualMemory(entity: VisualMemoryEntity)
    @Query("SELECT * FROM visual_memories ORDER BY capturedAt DESC LIMIT :limit") suspend fun getRecent(limit: Int): List<VisualMemoryEntity>
    @Query("SELECT * FROM visual_memories") fun observeAll(): Flow<List<VisualMemoryEntity>>
    @Delete suspend fun delete(entity: VisualMemoryEntity)
}
