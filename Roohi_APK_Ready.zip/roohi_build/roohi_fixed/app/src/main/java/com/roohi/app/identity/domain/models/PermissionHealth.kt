package com.roohi.app.identity.domain.models
data class PermissionHealth(
    val microphoneGranted: Boolean,
    val notificationsGranted: Boolean,
    val overlayGranted: Boolean,
    val batteryOptimizationIgnored: Boolean,
    val allCriticalGranted: Boolean
)
