package com.roohi.app.automation.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "automation_history")
data class ExecutionHistoryEntity(@PrimaryKey val id: String, val workflowId: String, val success: Boolean, val executedAt: Long = System.currentTimeMillis())
