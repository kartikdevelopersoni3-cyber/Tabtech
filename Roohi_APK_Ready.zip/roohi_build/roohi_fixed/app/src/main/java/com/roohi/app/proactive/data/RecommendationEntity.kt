package com.roohi.app.proactive.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "recommendations")
data class RecommendationEntity(@PrimaryKey val id: String, val title: String, val description: String, val priority: Int = 0, val createdAt: Long = System.currentTimeMillis(), val isShown: Boolean = false)
