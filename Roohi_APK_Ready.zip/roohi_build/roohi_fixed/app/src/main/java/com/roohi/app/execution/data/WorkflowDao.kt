package com.roohi.app.execution.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface WorkflowDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertWorkflow(workflow: WorkflowEntity)
    @Query("SELECT * FROM workflows") suspend fun getAllWorkflows(): List<WorkflowEntity>
    @Query("SELECT * FROM workflows") fun observeWorkflows(): Flow<List<WorkflowEntity>>
    @Delete suspend fun deleteWorkflow(workflow: WorkflowEntity)
}
