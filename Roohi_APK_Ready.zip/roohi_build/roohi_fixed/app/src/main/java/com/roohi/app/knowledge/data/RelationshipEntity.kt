package com.roohi.app.knowledge.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "knowledge_relationships")
data class RelationshipEntity(@PrimaryKey val id: String, val fromId: String, val toId: String, val relationshipType: String)
