package com.roohi.app.proactive.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface ProactiveDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertRecommendation(rec: RecommendationEntity)
    @Query("SELECT * FROM recommendations WHERE isShown = 0 ORDER BY priority DESC") suspend fun getPending(): List<RecommendationEntity>
    @Query("UPDATE recommendations SET isShown = 1 WHERE id = :id") suspend fun markShown(id: String)
    @Query("SELECT * FROM recommendations") fun observeAll(): Flow<List<RecommendationEntity>>
}
