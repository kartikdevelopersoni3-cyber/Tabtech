package com.roohi.app.conversation.domain.models
data class ConversationMessage(val id: String, val sessionId: String, val role: String, val content: String, val timestamp: Long = System.currentTimeMillis())
