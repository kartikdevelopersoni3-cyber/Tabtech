package com.roohi.app.personality.domain.models
data class SimulatedEmotion(val type: String, val intensity: Float, val trigger: String = "", val timestamp: Long = System.currentTimeMillis())
