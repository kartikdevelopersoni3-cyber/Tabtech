package com.roohi.app.reasoning.domain.models
data class ReasoningSession(val sessionId: String, val startedAt: Long = System.currentTimeMillis(), val isActive: Boolean = true, val turnCount: Int = 0)
