package com.roohi.app.execution.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "tasks")
data class TaskEntity(@PrimaryKey val id: String, val title: String, val status: String, val priority: Int = 0, val createdAt: Long = System.currentTimeMillis())
