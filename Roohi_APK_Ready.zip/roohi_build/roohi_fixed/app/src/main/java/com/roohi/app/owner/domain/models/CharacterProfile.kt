package com.roohi.app.owner.domain.models
data class CharacterProfile(val id: String, val characterName: String, val voiceStyle: String, val personalityTraits: List<String> = emptyList())
