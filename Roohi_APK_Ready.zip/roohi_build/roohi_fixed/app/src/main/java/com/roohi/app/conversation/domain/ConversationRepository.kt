package com.roohi.app.conversation.domain
import com.roohi.app.conversation.domain.models.ConversationMessage
import kotlinx.coroutines.flow.Flow
interface ConversationRepository {
    suspend fun saveMessage(message: ConversationMessage)
    suspend fun getSessionMessages(sessionId: String): List<ConversationMessage>
    fun observeMessages(sessionId: String): Flow<List<ConversationMessage>>
    suspend fun deleteSession(sessionId: String)
}
