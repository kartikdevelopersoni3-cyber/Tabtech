package com.roohi.app.memory.domain
import com.roohi.app.memory.domain.models.*
import kotlinx.coroutines.flow.Flow
interface MemoryRepository {
    suspend fun saveMemory(record: MemoryRecord)
    suspend fun getAllActiveMemories(): List<MemoryRecord>
    suspend fun searchMemories(query: String): List<MemoryRecord>
    suspend fun getMemoriesByType(type: MemoryType): List<MemoryRecord>
    fun observeActiveMemoryCount(): Flow<Int>
    suspend fun deleteMemory(id: String)
    suspend fun updateLastAccessed(id: String, timestamp: Long)
}
