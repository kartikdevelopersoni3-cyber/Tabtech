package com.roohi.app.automation.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "automation_workflows")
data class WorkflowEntity(@PrimaryKey val id: String, val name: String, val triggerType: String, val actionsJson: String, val isEnabled: Boolean = true, val createdAt: Long = System.currentTimeMillis())
