package com.roohi.app.automation.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface AutomationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertWorkflow(workflow: WorkflowEntity)
    @Query("SELECT * FROM automation_workflows WHERE isEnabled = 1") suspend fun getEnabledWorkflows(): List<WorkflowEntity>
    @Query("SELECT * FROM automation_workflows") fun observeAll(): Flow<List<WorkflowEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertHistory(history: ExecutionHistoryEntity)
}
