package com.roohi.app.owner.data
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class AvatarStorageLayer @Inject constructor(private val logger: Logger) {
    fun getAvatarPath(): String? = null
    fun saveAvatarPath(path: String) { logger.d("AvatarStorage", "Avatar path: $path") }
}
