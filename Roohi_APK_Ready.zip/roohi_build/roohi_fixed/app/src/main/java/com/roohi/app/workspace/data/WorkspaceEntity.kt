package com.roohi.app.workspace.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "workspaces")
data class WorkspaceEntity(@PrimaryKey val id: String, val name: String, val dataJson: String = "{}", val updatedAt: Long = System.currentTimeMillis())
