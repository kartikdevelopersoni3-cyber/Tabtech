package com.roohi.app.identity.domain.models
data class DeviceMetadata(val deviceId: String, val model: String, val osVersion: String, val registeredAt: Long)
