package com.roohi.app.execution.domain
import com.roohi.app.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class ExecutionPlanner @Inject constructor(private val logger: Logger) {
    fun planExecution(input: String): String = "DIRECT"
}
