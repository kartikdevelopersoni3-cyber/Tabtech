package com.roohi.app.command.domain.models
data class ExecutionResult(val commandId: String, val success: Boolean, val output: String = "", val errorMessage: String? = null, val executedAt: Long = System.currentTimeMillis())
