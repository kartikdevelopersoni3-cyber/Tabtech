package com.roohi.app.workspace.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface WorkspaceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertWorkspace(ws: WorkspaceEntity)
    @Query("SELECT * FROM workspaces") suspend fun getAllWorkspaces(): List<WorkspaceEntity>
    @Query("SELECT * FROM workspaces") fun observeAll(): Flow<List<WorkspaceEntity>>
    @Delete suspend fun deleteWorkspace(ws: WorkspaceEntity)
}
