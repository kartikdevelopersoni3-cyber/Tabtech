package com.roohi.app.command.domain.models
enum class CommandType { APP_LAUNCH, SYSTEM_CONTROL, MEDIA_CONTROL, REMINDER, SEARCH, NAVIGATION, COMMUNICATION, UNSUPPORTED }
