package com.roohi.app.execution.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "workflows")
data class WorkflowEntity(@PrimaryKey val id: String, val name: String, val stepsJson: String, val status: String, val createdAt: Long = System.currentTimeMillis())
