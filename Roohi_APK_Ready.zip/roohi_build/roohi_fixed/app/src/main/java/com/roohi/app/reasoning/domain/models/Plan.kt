package com.roohi.app.reasoning.domain.models
data class Plan(val id: String, val goalId: String, val steps: List<PlanStep>, val status: PlanStatus = PlanStatus.DRAFT, val createdAt: Long = System.currentTimeMillis())
